import './index.css'

const BrowserHistory = props => {
  const {browserDetails, onDeleteItem} = props
  const {timeAccessed, logoUrl, title, domainUrl, id} = browserDetails
  const deleteHistory = () => {
    onDeleteItem(id)
  }

  return (
    <li className="bg-container">
      <li className="item-container">
        <p className="time">{timeAccessed}</p>
        <img src={logoUrl} alt="domain logo" className="image" />
        <p className="title">{title}</p>
        <p className="domain-name">{domainUrl}</p>
      </li>

      <button
        data-testid="delete"
        type="button"
        className="button"
        onClick={deleteHistory}
      >
        <img
          src="https://assets.ccbp.in/frontend/react-js/delete-img.png"
          alt="delete"
        />
      </button>
    </li>
  )
}
export default BrowserHistory
